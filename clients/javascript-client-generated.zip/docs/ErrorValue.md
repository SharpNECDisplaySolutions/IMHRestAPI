# NecDisplaysApi.ErrorValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **Number** | Specific error | [optional] 
