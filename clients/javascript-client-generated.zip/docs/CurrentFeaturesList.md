# NecDisplaysApi.CurrentFeaturesList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**functions** | **[String]** |  | [optional] 
