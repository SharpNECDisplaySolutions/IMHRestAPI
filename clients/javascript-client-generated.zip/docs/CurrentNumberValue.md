# NecDisplaysApi.CurrentNumberValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentValue** | **Number** |  | [optional] 
