# NecDisplaysApi.CurrentValueNamePair

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentValue** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
