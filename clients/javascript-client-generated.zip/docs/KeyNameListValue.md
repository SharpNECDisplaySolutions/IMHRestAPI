# NecDisplaysApi.KeyNameListValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**elements** | [**KeyNameList**](KeyNameList.md) |  | [optional] 
