# NecDisplaysApi.CurrentValueNameList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
