# NecDisplaysApi.ErrorStatusList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | **[String]** |  | [optional] 
