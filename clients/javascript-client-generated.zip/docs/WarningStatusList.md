# NecDisplaysApi.WarningStatusList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**warnings** | **[String]** |  | [optional] 
