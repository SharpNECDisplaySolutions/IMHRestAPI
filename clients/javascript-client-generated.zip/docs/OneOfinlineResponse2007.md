# NecDisplaysApi.OneOfinlineResponse2007

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
