# NecDisplaysApi.CurrentStringValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentValue** | **String** |  | [optional] 
