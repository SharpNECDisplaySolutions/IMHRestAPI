# NecDisplaysApi.DefaultApi

All URIs are relative to *http://{displayIp}/api/{version}*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAvmute**](DefaultApi.md#getAvmute) | **GET** /avmute | Get the Audio/Video mute status
[**getBacklight**](DefaultApi.md#getBacklight) | **GET** /backlight | Get the current backlight
[**getBrightness**](DefaultApi.md#getBrightness) | **GET** /brightness | Get the current brightness in relation to the background
[**getColor**](DefaultApi.md#getColor) | **GET** /color | Get the current color
[**getContrast**](DefaultApi.md#getContrast) | **GET** /contrast | Get the current contrast
[**getErrorStatus**](DefaultApi.md#getErrorStatus) | **GET** /error_status | Get the error status.
[**getErrorStatusList**](DefaultApi.md#getErrorStatusList) | **GET** /error_status/list | Get a list of the error status names.
[**getFreeze**](DefaultApi.md#getFreeze) | **GET** /freeze | Get the current freeze
[**getInput**](DefaultApi.md#getInput) | **GET** /inputs | Gets current terminal input
[**getInputList**](DefaultApi.md#getInputList) | **GET** /inputs/list | Returns the list of inputs by key-name pairs
[**getModelName**](DefaultApi.md#getModelName) | **GET** /product_name | Get the model name of the display
[**getPowerState**](DefaultApi.md#getPowerState) | **GET** /power | Get the power state
[**getSharpness**](DefaultApi.md#getSharpness) | **GET** /sharpness | Get the current sharpness
[**getSupportedFeatures**](DefaultApi.md#getSupportedFeatures) | **GET** /list | Get the API supported features
[**getUsage**](DefaultApi.md#getUsage) | **GET** /usage | Get the usage status.
[**getVolume**](DefaultApi.md#getVolume) | **GET** /volume | Get the current volume
[**getWarningStatus**](DefaultApi.md#getWarningStatus) | **GET** /warning_status | Get the warning status.
[**getWarningStatusList**](DefaultApi.md#getWarningStatusList) | **GET** /warning_status/list | Get a list of the warning status names
[**putAvmute**](DefaultApi.md#putAvmute) | **PUT** /avmute | Set the Audio/Video mute status
[**putBacklight**](DefaultApi.md#putBacklight) | **PUT** /backlight | Set the current backlight. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**putBrightness**](DefaultApi.md#putBrightness) | **PUT** /brightness | Set the current brightness in relation to the background. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**putColor**](DefaultApi.md#putColor) | **PUT** /color | Set the current color. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**putContrast**](DefaultApi.md#putContrast) | **PUT** /contrast | Set the current contrast.  Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**putFreeze**](DefaultApi.md#putFreeze) | **PUT** /freeze | Set the current freeze.  0&#x3D;Off, 1&#x3D;On
[**putInput**](DefaultApi.md#putInput) | **PUT** /inputs | Switch the current input terminal
[**putPowerState**](DefaultApi.md#putPowerState) | **PUT** /power | Set the power state.
[**putSharpness**](DefaultApi.md#putSharpness) | **PUT** /sharpness | Set the current sharpness. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**putVolume**](DefaultApi.md#putVolume) | **PUT** /volume | Set the current volume.  The range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

<a name="getAvmute"></a>
# **getAvmute**
> InlineResponse200 getAvmute()

Get the Audio/Video mute status

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getAvmute((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getBacklight"></a>
# **getBacklight**
> InlineResponse200 getBacklight()

Get the current backlight

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getBacklight((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getBrightness"></a>
# **getBrightness**
> InlineResponse200 getBrightness()

Get the current brightness in relation to the background

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getBrightness((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getColor"></a>
# **getColor**
> InlineResponse200 getColor()

Get the current color

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getColor((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getContrast"></a>
# **getContrast**
> InlineResponse200 getContrast()

Get the current contrast

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getContrast((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getErrorStatus"></a>
# **getErrorStatus**
> InlineResponse2004 getErrorStatus()

Get the error status.

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getErrorStatus((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getErrorStatusList"></a>
# **getErrorStatusList**
> InlineResponse2006 getErrorStatusList()

Get a list of the error status names.

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getErrorStatusList((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getFreeze"></a>
# **getFreeze**
> InlineResponse200 getFreeze()

Get the current freeze

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getFreeze((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getInput"></a>
# **getInput**
> InlineResponse200 getInput()

Gets current terminal input

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getInput((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getInputList"></a>
# **getInputList**
> InlineResponse2001 getInputList()

Returns the list of inputs by key-name pairs

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getInputList((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getModelName"></a>
# **getModelName**
> InlineResponse2002 getModelName()

Get the model name of the display

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getModelName((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getPowerState"></a>
# **getPowerState**
> InlineResponse200 getPowerState()

Get the power state

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getPowerState((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getSharpness"></a>
# **getSharpness**
> InlineResponse200 getSharpness()

Get the current sharpness

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getSharpness((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getSupportedFeatures"></a>
# **getSupportedFeatures**
> InlineResponse2008 getSupportedFeatures()

Get the API supported features

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getSupportedFeatures((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2008**](InlineResponse2008.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getUsage"></a>
# **getUsage**
> InlineResponse2003 getUsage()

Get the usage status.

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getUsage((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getVolume"></a>
# **getVolume**
> InlineResponse200 getVolume()

Get the current volume

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getVolume((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getWarningStatus"></a>
# **getWarningStatus**
> InlineResponse2005 getWarningStatus()

Get the warning status.

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getWarningStatus((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getWarningStatusList"></a>
# **getWarningStatusList**
> InlineResponse2007 getWarningStatusList()

Get a list of the warning status names

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
apiInstance.getWarningStatusList((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2007**](InlineResponse2007.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="putAvmute"></a>
# **putAvmute**
> ErrorValue putAvmute(value)

Set the Audio/Video mute status

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
let value = 56; // Number | Value of 0 turns video and audio mute off, 1 turns video mute on, 2 turns audio mute on and 3 turns both video and audio mute on

apiInstance.putAvmute(value, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **Number**| Value of 0 turns video and audio mute off, 1 turns video mute on, 2 turns audio mute on and 3 turns both video and audio mute on | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="putBacklight"></a>
# **putBacklight**
> ErrorValue putBacklight(value)

Set the current backlight. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
let value = "value_example"; // String | Change the backlight.  Range is 0-100.

apiInstance.putBacklight(value, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **String**| Change the backlight.  Range is 0-100. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="putBrightness"></a>
# **putBrightness**
> ErrorValue putBrightness(value)

Set the current brightness in relation to the background. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
let value = "value_example"; // String | Change the brightness.  Range is 0-100

apiInstance.putBrightness(value, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **String**| Change the brightness.  Range is 0-100 | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="putColor"></a>
# **putColor**
> ErrorValue putColor(value)

Set the current color. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
let value = "value_example"; // String | Change the color.  Range is 0-100.

apiInstance.putColor(value, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **String**| Change the color.  Range is 0-100. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="putContrast"></a>
# **putContrast**
> ErrorValue putContrast(value)

Set the current contrast.  Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
let value = "value_example"; // String | Change the contrast.  Range is 0-100.

apiInstance.putContrast(value, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **String**| Change the contrast.  Range is 0-100. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="putFreeze"></a>
# **putFreeze**
> ErrorValue putFreeze(value)

Set the current freeze.  0&#x3D;Off, 1&#x3D;On

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
let value = 56; // Number | Change the freeze.

apiInstance.putFreeze(value, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **Number**| Change the freeze. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="putInput"></a>
# **putInput**
> ErrorValue putInput(value)

Switch the current input terminal

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
let value = 56; // Number | Change the input.  Call inputs/list before this to get a list of valid inputs and names. Sample inputs are 1=HDMI1, 2=HDMI2, and 11=DisplayPort

apiInstance.putInput(value, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **Number**| Change the input.  Call inputs/list before this to get a list of valid inputs and names. Sample inputs are 1&#x3D;HDMI1, 2&#x3D;HDMI2, and 11&#x3D;DisplayPort | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="putPowerState"></a>
# **putPowerState**
> ErrorValue putPowerState(value)

Set the power state.

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
let value = 56; // Number | Value of 0 turns the display off and 1 turns the display on.

apiInstance.putPowerState(value, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **Number**| Value of 0 turns the display off and 1 turns the display on. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="putSharpness"></a>
# **putSharpness**
> ErrorValue putSharpness(value)

Set the current sharpness. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
let value = "value_example"; // String | Change the sharpness.

apiInstance.putSharpness(value, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **String**| Change the sharpness. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="putVolume"></a>
# **putVolume**
> ErrorValue putVolume(value)

Set the current volume.  The range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```javascript
import NecDisplaysApi from 'nec_displays_api';

let apiInstance = new NecDisplaysApi.DefaultApi();
let value = "value_example"; // String | Change the volume.  Range is 0-100.

apiInstance.putVolume(value, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **String**| Change the volume.  Range is 0-100. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

