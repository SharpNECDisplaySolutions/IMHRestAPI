# CurrentErrorStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **string** | Error code of the display | [optional] 
**id** | **string** | Error ID | [optional] 
**detail** | **string** | Detail.  Note this field may or may not be present | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

