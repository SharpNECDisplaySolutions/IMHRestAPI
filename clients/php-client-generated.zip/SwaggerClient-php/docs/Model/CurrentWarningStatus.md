# CurrentWarningStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**warning** | **string** | Warning code of the display | [optional] 
**id** | **string** | Warning ID | [optional] 
**detail** | **string** | Detail.  Note this field may or may not be present | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

