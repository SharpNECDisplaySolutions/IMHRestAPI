# Swagger\Client\DefaultApi

All URIs are relative to *http://{displayIp}/api/{version}*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAvmute**](DefaultApi.md#getavmute) | **GET** /avmute | Get the Audio/Video mute status
[**getBacklight**](DefaultApi.md#getbacklight) | **GET** /backlight | Get the current backlight
[**getBrightness**](DefaultApi.md#getbrightness) | **GET** /brightness | Get the current brightness in relation to the background
[**getColor**](DefaultApi.md#getcolor) | **GET** /color | Get the current color
[**getContrast**](DefaultApi.md#getcontrast) | **GET** /contrast | Get the current contrast
[**getErrorStatus**](DefaultApi.md#geterrorstatus) | **GET** /error_status | Get the error status.
[**getErrorStatusList**](DefaultApi.md#geterrorstatuslist) | **GET** /error_status/list | Get a list of the error status names.
[**getFreeze**](DefaultApi.md#getfreeze) | **GET** /freeze | Get the current freeze
[**getInput**](DefaultApi.md#getinput) | **GET** /inputs | Gets current terminal input
[**getInputList**](DefaultApi.md#getinputlist) | **GET** /inputs/list | Returns the list of inputs by key-name pairs
[**getModelName**](DefaultApi.md#getmodelname) | **GET** /product_name | Get the model name of the display
[**getPowerState**](DefaultApi.md#getpowerstate) | **GET** /power | Get the power state
[**getSharpness**](DefaultApi.md#getsharpness) | **GET** /sharpness | Get the current sharpness
[**getSupportedFeatures**](DefaultApi.md#getsupportedfeatures) | **GET** /list | Get the API supported features
[**getUsage**](DefaultApi.md#getusage) | **GET** /usage | Get the usage status.
[**getVolume**](DefaultApi.md#getvolume) | **GET** /volume | Get the current volume
[**getWarningStatus**](DefaultApi.md#getwarningstatus) | **GET** /warning_status | Get the warning status.
[**getWarningStatusList**](DefaultApi.md#getwarningstatuslist) | **GET** /warning_status/list | Get a list of the warning status names
[**putAvmute**](DefaultApi.md#putavmute) | **PUT** /avmute | Set the Audio/Video mute status
[**putBacklight**](DefaultApi.md#putbacklight) | **PUT** /backlight | Set the current backlight. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**putBrightness**](DefaultApi.md#putbrightness) | **PUT** /brightness | Set the current brightness in relation to the background. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**putColor**](DefaultApi.md#putcolor) | **PUT** /color | Set the current color. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**putContrast**](DefaultApi.md#putcontrast) | **PUT** /contrast | Set the current contrast.  Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**putFreeze**](DefaultApi.md#putfreeze) | **PUT** /freeze | Set the current freeze.  0&#x3D;Off, 1&#x3D;On
[**putInput**](DefaultApi.md#putinput) | **PUT** /inputs | Switch the current input terminal
[**putPowerState**](DefaultApi.md#putpowerstate) | **PUT** /power | Set the power state.
[**putSharpness**](DefaultApi.md#putsharpness) | **PUT** /sharpness | Set the current sharpness. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**putVolume**](DefaultApi.md#putvolume) | **PUT** /volume | Set the current volume.  The range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

# **getAvmute**
> \Swagger\Client\Model\InlineResponse200 getAvmute()

Get the Audio/Video mute status

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getAvmute();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getAvmute: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse200**](../Model/InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getBacklight**
> \Swagger\Client\Model\InlineResponse200 getBacklight()

Get the current backlight

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getBacklight();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getBacklight: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse200**](../Model/InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getBrightness**
> \Swagger\Client\Model\InlineResponse200 getBrightness()

Get the current brightness in relation to the background

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getBrightness();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getBrightness: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse200**](../Model/InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getColor**
> \Swagger\Client\Model\InlineResponse200 getColor()

Get the current color

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getColor();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getColor: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse200**](../Model/InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getContrast**
> \Swagger\Client\Model\InlineResponse200 getContrast()

Get the current contrast

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getContrast();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getContrast: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse200**](../Model/InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getErrorStatus**
> \Swagger\Client\Model\InlineResponse2004 getErrorStatus()

Get the error status.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getErrorStatus();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getErrorStatus: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse2004**](../Model/InlineResponse2004.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getErrorStatusList**
> \Swagger\Client\Model\InlineResponse2006 getErrorStatusList()

Get a list of the error status names.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getErrorStatusList();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getErrorStatusList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse2006**](../Model/InlineResponse2006.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getFreeze**
> \Swagger\Client\Model\InlineResponse200 getFreeze()

Get the current freeze

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getFreeze();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getFreeze: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse200**](../Model/InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getInput**
> \Swagger\Client\Model\InlineResponse200 getInput()

Gets current terminal input

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getInput();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getInput: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse200**](../Model/InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getInputList**
> \Swagger\Client\Model\InlineResponse2001 getInputList()

Returns the list of inputs by key-name pairs

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getInputList();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getInputList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse2001**](../Model/InlineResponse2001.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getModelName**
> \Swagger\Client\Model\InlineResponse2002 getModelName()

Get the model name of the display

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getModelName();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getModelName: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse2002**](../Model/InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getPowerState**
> \Swagger\Client\Model\InlineResponse200 getPowerState()

Get the power state

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getPowerState();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getPowerState: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse200**](../Model/InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getSharpness**
> \Swagger\Client\Model\InlineResponse200 getSharpness()

Get the current sharpness

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getSharpness();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getSharpness: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse200**](../Model/InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getSupportedFeatures**
> \Swagger\Client\Model\InlineResponse2008 getSupportedFeatures()

Get the API supported features

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getSupportedFeatures();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getSupportedFeatures: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse2008**](../Model/InlineResponse2008.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getUsage**
> \Swagger\Client\Model\InlineResponse2003 getUsage()

Get the usage status.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getUsage();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getUsage: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse2003**](../Model/InlineResponse2003.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getVolume**
> \Swagger\Client\Model\InlineResponse200 getVolume()

Get the current volume

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getVolume();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getVolume: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse200**](../Model/InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getWarningStatus**
> \Swagger\Client\Model\InlineResponse2005 getWarningStatus()

Get the warning status.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getWarningStatus();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getWarningStatus: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse2005**](../Model/InlineResponse2005.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getWarningStatusList**
> \Swagger\Client\Model\InlineResponse2007 getWarningStatusList()

Get a list of the warning status names

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getWarningStatusList();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->getWarningStatusList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\InlineResponse2007**](../Model/InlineResponse2007.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **putAvmute**
> \Swagger\Client\Model\ErrorValue putAvmute($value)

Set the Audio/Video mute status

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$value = 56; // int | Value of 0 turns video and audio mute off, 1 turns video mute on, 2 turns audio mute on and 3 turns both video and audio mute on

try {
    $result = $apiInstance->putAvmute($value);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->putAvmute: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **int**| Value of 0 turns video and audio mute off, 1 turns video mute on, 2 turns audio mute on and 3 turns both video and audio mute on |

### Return type

[**\Swagger\Client\Model\ErrorValue**](../Model/ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **putBacklight**
> \Swagger\Client\Model\ErrorValue putBacklight($value)

Set the current backlight. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$value = "value_example"; // string | Change the backlight.  Range is 0-100.

try {
    $result = $apiInstance->putBacklight($value);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->putBacklight: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **string**| Change the backlight.  Range is 0-100. |

### Return type

[**\Swagger\Client\Model\ErrorValue**](../Model/ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **putBrightness**
> \Swagger\Client\Model\ErrorValue putBrightness($value)

Set the current brightness in relation to the background. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$value = "value_example"; // string | Change the brightness.  Range is 0-100

try {
    $result = $apiInstance->putBrightness($value);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->putBrightness: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **string**| Change the brightness.  Range is 0-100 |

### Return type

[**\Swagger\Client\Model\ErrorValue**](../Model/ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **putColor**
> \Swagger\Client\Model\ErrorValue putColor($value)

Set the current color. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$value = "value_example"; // string | Change the color.  Range is 0-100.

try {
    $result = $apiInstance->putColor($value);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->putColor: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **string**| Change the color.  Range is 0-100. |

### Return type

[**\Swagger\Client\Model\ErrorValue**](../Model/ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **putContrast**
> \Swagger\Client\Model\ErrorValue putContrast($value)

Set the current contrast.  Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$value = "value_example"; // string | Change the contrast.  Range is 0-100.

try {
    $result = $apiInstance->putContrast($value);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->putContrast: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **string**| Change the contrast.  Range is 0-100. |

### Return type

[**\Swagger\Client\Model\ErrorValue**](../Model/ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **putFreeze**
> \Swagger\Client\Model\ErrorValue putFreeze($value)

Set the current freeze.  0=Off, 1=On

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$value = 56; // int | Change the freeze.

try {
    $result = $apiInstance->putFreeze($value);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->putFreeze: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **int**| Change the freeze. |

### Return type

[**\Swagger\Client\Model\ErrorValue**](../Model/ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **putInput**
> \Swagger\Client\Model\ErrorValue putInput($value)

Switch the current input terminal

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$value = 56; // int | Change the input.  Call inputs/list before this to get a list of valid inputs and names. Sample inputs are 1=HDMI1, 2=HDMI2, and 11=DisplayPort

try {
    $result = $apiInstance->putInput($value);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->putInput: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **int**| Change the input.  Call inputs/list before this to get a list of valid inputs and names. Sample inputs are 1&#x3D;HDMI1, 2&#x3D;HDMI2, and 11&#x3D;DisplayPort |

### Return type

[**\Swagger\Client\Model\ErrorValue**](../Model/ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **putPowerState**
> \Swagger\Client\Model\ErrorValue putPowerState($value)

Set the power state.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$value = 56; // int | Value of 0 turns the display off and 1 turns the display on.

try {
    $result = $apiInstance->putPowerState($value);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->putPowerState: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **int**| Value of 0 turns the display off and 1 turns the display on. |

### Return type

[**\Swagger\Client\Model\ErrorValue**](../Model/ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **putSharpness**
> \Swagger\Client\Model\ErrorValue putSharpness($value)

Set the current sharpness. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$value = "value_example"; // string | Change the sharpness.

try {
    $result = $apiInstance->putSharpness($value);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->putSharpness: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **string**| Change the sharpness. |

### Return type

[**\Swagger\Client\Model\ErrorValue**](../Model/ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **putVolume**
> \Swagger\Client\Model\ErrorValue putVolume($value)

Set the current volume.  The range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$value = "value_example"; // string | Change the volume.  Range is 0-100.

try {
    $result = $apiInstance->putVolume($value);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->putVolume: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **string**| Change the volume.  Range is 0-100. |

### Return type

[**\Swagger\Client\Model\ErrorValue**](../Model/ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

