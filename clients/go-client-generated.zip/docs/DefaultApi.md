# {{classname}}

All URIs are relative to *http://{displayIp}/api/{version}*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetAvmute**](DefaultApi.md#GetAvmute) | **Get** /avmute | Get the Audio/Video mute status
[**GetBacklight**](DefaultApi.md#GetBacklight) | **Get** /backlight | Get the current backlight
[**GetBrightness**](DefaultApi.md#GetBrightness) | **Get** /brightness | Get the current brightness in relation to the background
[**GetColor**](DefaultApi.md#GetColor) | **Get** /color | Get the current color
[**GetContrast**](DefaultApi.md#GetContrast) | **Get** /contrast | Get the current contrast
[**GetErrorStatus**](DefaultApi.md#GetErrorStatus) | **Get** /error_status | Get the error status.
[**GetErrorStatusList**](DefaultApi.md#GetErrorStatusList) | **Get** /error_status/list | Get a list of the error status names.
[**GetFreeze**](DefaultApi.md#GetFreeze) | **Get** /freeze | Get the current freeze
[**GetInput**](DefaultApi.md#GetInput) | **Get** /inputs | Gets current terminal input
[**GetInputList**](DefaultApi.md#GetInputList) | **Get** /inputs/list | Returns the list of inputs by key-name pairs
[**GetModelName**](DefaultApi.md#GetModelName) | **Get** /product_name | Get the model name of the display
[**GetPowerState**](DefaultApi.md#GetPowerState) | **Get** /power | Get the power state
[**GetSharpness**](DefaultApi.md#GetSharpness) | **Get** /sharpness | Get the current sharpness
[**GetSupportedFeatures**](DefaultApi.md#GetSupportedFeatures) | **Get** /list | Get the API supported features
[**GetUsage**](DefaultApi.md#GetUsage) | **Get** /usage | Get the usage status.
[**GetVolume**](DefaultApi.md#GetVolume) | **Get** /volume | Get the current volume
[**GetWarningStatus**](DefaultApi.md#GetWarningStatus) | **Get** /warning_status | Get the warning status.
[**GetWarningStatusList**](DefaultApi.md#GetWarningStatusList) | **Get** /warning_status/list | Get a list of the warning status names
[**PutAvmute**](DefaultApi.md#PutAvmute) | **Put** /avmute | Set the Audio/Video mute status
[**PutBacklight**](DefaultApi.md#PutBacklight) | **Put** /backlight | Set the current backlight. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**PutBrightness**](DefaultApi.md#PutBrightness) | **Put** /brightness | Set the current brightness in relation to the background. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**PutColor**](DefaultApi.md#PutColor) | **Put** /color | Set the current color. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**PutContrast**](DefaultApi.md#PutContrast) | **Put** /contrast | Set the current contrast.  Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**PutFreeze**](DefaultApi.md#PutFreeze) | **Put** /freeze | Set the current freeze.  0&#x3D;Off, 1&#x3D;On
[**PutInput**](DefaultApi.md#PutInput) | **Put** /inputs | Switch the current input terminal
[**PutPowerState**](DefaultApi.md#PutPowerState) | **Put** /power | Set the power state.
[**PutSharpness**](DefaultApi.md#PutSharpness) | **Put** /sharpness | Set the current sharpness. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**PutVolume**](DefaultApi.md#PutVolume) | **Put** /volume | Set the current volume.  The range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

# **GetAvmute**
> InlineResponse200 GetAvmute(ctx, )
Get the Audio/Video mute status

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](inline_response_200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetBacklight**
> InlineResponse200 GetBacklight(ctx, )
Get the current backlight

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](inline_response_200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetBrightness**
> InlineResponse200 GetBrightness(ctx, )
Get the current brightness in relation to the background

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](inline_response_200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetColor**
> InlineResponse200 GetColor(ctx, )
Get the current color

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](inline_response_200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetContrast**
> InlineResponse200 GetContrast(ctx, )
Get the current contrast

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](inline_response_200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetErrorStatus**
> InlineResponse2004 GetErrorStatus(ctx, )
Get the error status.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2004**](inline_response_200_4.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetErrorStatusList**
> InlineResponse2006 GetErrorStatusList(ctx, )
Get a list of the error status names.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2006**](inline_response_200_6.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetFreeze**
> InlineResponse200 GetFreeze(ctx, )
Get the current freeze

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](inline_response_200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetInput**
> InlineResponse200 GetInput(ctx, )
Gets current terminal input

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](inline_response_200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetInputList**
> InlineResponse2001 GetInputList(ctx, )
Returns the list of inputs by key-name pairs

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2001**](inline_response_200_1.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetModelName**
> InlineResponse2002 GetModelName(ctx, )
Get the model name of the display

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2002**](inline_response_200_2.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetPowerState**
> InlineResponse200 GetPowerState(ctx, )
Get the power state

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](inline_response_200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetSharpness**
> InlineResponse200 GetSharpness(ctx, )
Get the current sharpness

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](inline_response_200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetSupportedFeatures**
> InlineResponse2008 GetSupportedFeatures(ctx, )
Get the API supported features

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2008**](inline_response_200_8.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetUsage**
> InlineResponse2003 GetUsage(ctx, )
Get the usage status.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2003**](inline_response_200_3.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetVolume**
> InlineResponse200 GetVolume(ctx, )
Get the current volume

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](inline_response_200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetWarningStatus**
> InlineResponse2005 GetWarningStatus(ctx, )
Get the warning status.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2005**](inline_response_200_5.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetWarningStatusList**
> InlineResponse2007 GetWarningStatusList(ctx, )
Get a list of the warning status names

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2007**](inline_response_200_7.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PutAvmute**
> ErrorValue PutAvmute(ctx, value)
Set the Audio/Video mute status

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **value** | **int32**| Value of 0 turns video and audio mute off, 1 turns video mute on, 2 turns audio mute on and 3 turns both video and audio mute on | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PutBacklight**
> ErrorValue PutBacklight(ctx, value)
Set the current backlight. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **value** | **string**| Change the backlight.  Range is 0-100. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PutBrightness**
> ErrorValue PutBrightness(ctx, value)
Set the current brightness in relation to the background. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **value** | **string**| Change the brightness.  Range is 0-100 | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PutColor**
> ErrorValue PutColor(ctx, value)
Set the current color. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **value** | **string**| Change the color.  Range is 0-100. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PutContrast**
> ErrorValue PutContrast(ctx, value)
Set the current contrast.  Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **value** | **string**| Change the contrast.  Range is 0-100. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PutFreeze**
> ErrorValue PutFreeze(ctx, value)
Set the current freeze.  0=Off, 1=On

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **value** | **int32**| Change the freeze. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PutInput**
> ErrorValue PutInput(ctx, value)
Switch the current input terminal

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **value** | **int32**| Change the input.  Call inputs/list before this to get a list of valid inputs and names. Sample inputs are 1&#x3D;HDMI1, 2&#x3D;HDMI2, and 11&#x3D;DisplayPort | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PutPowerState**
> ErrorValue PutPowerState(ctx, value)
Set the power state.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **value** | **int32**| Value of 0 turns the display off and 1 turns the display on. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PutSharpness**
> ErrorValue PutSharpness(ctx, value)
Set the current sharpness. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **value** | **string**| Change the sharpness. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PutVolume**
> ErrorValue PutVolume(ctx, value)
Set the current volume.  The range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **value** | **string**| Change the volume.  Range is 0-100. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

