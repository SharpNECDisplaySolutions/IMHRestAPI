# CurrentErrorStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Error_** | **string** | Error code of the display | [optional] [default to null]
**Id** | **string** | Error ID | [optional] [default to null]
**Detail** | **string** | Detail.  Note this field may or may not be present | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

