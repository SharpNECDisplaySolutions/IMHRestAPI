# ApiStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Version** | **string** | API version | [optional] [default to null]
**Status** | **string** | Status of the version.  Statuses are stable, experimental or obsolete | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

