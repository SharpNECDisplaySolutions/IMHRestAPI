import 'package:swagger/api.dart';
import 'package:test/test.dart';


/// tests for DefaultApi
void main() {
  var instance = new DefaultApi();

  group('tests for DefaultApi', () {
    // Get the Audio/Video mute status
    //
    //Future<InlineResponse200> getAvmute() async
    test('test getAvmute', () async {
      // TODO
    });

    // Get the current backlight
    //
    //Future<InlineResponse200> getBacklight() async
    test('test getBacklight', () async {
      // TODO
    });

    // Get the current brightness in relation to the background
    //
    //Future<InlineResponse200> getBrightness() async
    test('test getBrightness', () async {
      // TODO
    });

    // Get the current color
    //
    //Future<InlineResponse200> getColor() async
    test('test getColor', () async {
      // TODO
    });

    // Get the current contrast
    //
    //Future<InlineResponse200> getContrast() async
    test('test getContrast', () async {
      // TODO
    });

    // Get the error status.
    //
    //Future<InlineResponse2004> getErrorStatus() async
    test('test getErrorStatus', () async {
      // TODO
    });

    // Get a list of the error status names.
    //
    //Future<InlineResponse2006> getErrorStatusList() async
    test('test getErrorStatusList', () async {
      // TODO
    });

    // Get the current freeze
    //
    //Future<InlineResponse200> getFreeze() async
    test('test getFreeze', () async {
      // TODO
    });

    // Gets current terminal input
    //
    //Future<InlineResponse200> getInput() async
    test('test getInput', () async {
      // TODO
    });

    // Returns the list of inputs by key-name pairs
    //
    //Future<InlineResponse2001> getInputList() async
    test('test getInputList', () async {
      // TODO
    });

    // Get the model name of the display
    //
    //Future<InlineResponse2002> getModelName() async
    test('test getModelName', () async {
      // TODO
    });

    // Get the power state
    //
    //Future<InlineResponse200> getPowerState() async
    test('test getPowerState', () async {
      // TODO
    });

    // Get the current sharpness
    //
    //Future<InlineResponse200> getSharpness() async
    test('test getSharpness', () async {
      // TODO
    });

    // Get the API supported features
    //
    //Future<InlineResponse2008> getSupportedFeatures() async
    test('test getSupportedFeatures', () async {
      // TODO
    });

    // Get the usage status.
    //
    //Future<InlineResponse2003> getUsage() async
    test('test getUsage', () async {
      // TODO
    });

    // Get the current volume
    //
    //Future<InlineResponse200> getVolume() async
    test('test getVolume', () async {
      // TODO
    });

    // Get the warning status.
    //
    //Future<InlineResponse2005> getWarningStatus() async
    test('test getWarningStatus', () async {
      // TODO
    });

    // Get a list of the warning status names
    //
    //Future<InlineResponse2007> getWarningStatusList() async
    test('test getWarningStatusList', () async {
      // TODO
    });

    // Set the Audio/Video mute status
    //
    //Future<ErrorValue> putAvmute(int value) async
    test('test putAvmute', () async {
      // TODO
    });

    // Set the current backlight. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
    //
    //Future<ErrorValue> putBacklight(String value) async
    test('test putBacklight', () async {
      // TODO
    });

    // Set the current brightness in relation to the background. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
    //
    //Future<ErrorValue> putBrightness(String value) async
    test('test putBrightness', () async {
      // TODO
    });

    // Set the current color. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
    //
    //Future<ErrorValue> putColor(String value) async
    test('test putColor', () async {
      // TODO
    });

    // Set the current contrast.  Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
    //
    //Future<ErrorValue> putContrast(String value) async
    test('test putContrast', () async {
      // TODO
    });

    // Set the current freeze.  0=Off, 1=On
    //
    //Future<ErrorValue> putFreeze(int value) async
    test('test putFreeze', () async {
      // TODO
    });

    // Switch the current input terminal
    //
    //Future<ErrorValue> putInput(int value) async
    test('test putInput', () async {
      // TODO
    });

    // Set the power state.
    //
    //Future<ErrorValue> putPowerState(int value) async
    test('test putPowerState', () async {
      // TODO
    });

    // Set the current sharpness. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
    //
    //Future<ErrorValue> putSharpness(String value) async
    test('test putSharpness', () async {
      // TODO
    });

    // Set the current volume.  The range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
    //
    //Future<ErrorValue> putVolume(String value) async
    test('test putVolume', () async {
      // TODO
    });

  });
}
