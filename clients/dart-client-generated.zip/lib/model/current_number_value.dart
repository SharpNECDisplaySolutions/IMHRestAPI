part of swagger.api;

class CurrentNumberValue {
  
  int currentValue = null;

  CurrentNumberValue();

  @override
  String toString() {
    return 'CurrentNumberValue[currentValue=$currentValue, ]';
  }

  CurrentNumberValue.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    currentValue = json['current_value'];
  }

  Map<String, dynamic> toJson() {
    return {
      'current_value': currentValue
     };
  }

  static List<CurrentNumberValue> listFromJson(List<dynamic> json) {
    return json == null ? new List<CurrentNumberValue>() : json.map((value) => new CurrentNumberValue.fromJson(value)).toList();
  }

  static Map<String, CurrentNumberValue> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, CurrentNumberValue>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new CurrentNumberValue.fromJson(value));
    }
    return map;
  }
}
