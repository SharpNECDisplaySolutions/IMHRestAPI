part of swagger.api;

class ErrorStatusList {
  
  List<String> errors = [];

  ErrorStatusList();

  @override
  String toString() {
    return 'ErrorStatusList[errors=$errors, ]';
  }

  ErrorStatusList.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    errors = (json['errors'] as List).map((item) => item as String).toList();
  }

  Map<String, dynamic> toJson() {
    return {
      'errors': errors
     };
  }

  static List<ErrorStatusList> listFromJson(List<dynamic> json) {
    return json == null ? new List<ErrorStatusList>() : json.map((value) => new ErrorStatusList.fromJson(value)).toList();
  }

  static Map<String, ErrorStatusList> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, ErrorStatusList>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new ErrorStatusList.fromJson(value));
    }
    return map;
  }
}
