part of swagger.api;

class OneOfinlineResponse2006 {
  
  OneOfinlineResponse2006();

  @override
  String toString() {
    return 'OneOfinlineResponse2006[]';
  }

  OneOfinlineResponse2006.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
  }

  Map<String, dynamic> toJson() {
    return {
     };
  }

  static List<OneOfinlineResponse2006> listFromJson(List<dynamic> json) {
    return json == null ? new List<OneOfinlineResponse2006>() : json.map((value) => new OneOfinlineResponse2006.fromJson(value)).toList();
  }

  static Map<String, OneOfinlineResponse2006> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, OneOfinlineResponse2006>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new OneOfinlineResponse2006.fromJson(value));
    }
    return map;
  }
}
