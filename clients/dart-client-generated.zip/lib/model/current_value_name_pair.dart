part of swagger.api;

class CurrentValueNamePair {
  
  int currentValue = null;

  String name = null;

  CurrentValueNamePair();

  @override
  String toString() {
    return 'CurrentValueNamePair[currentValue=$currentValue, name=$name, ]';
  }

  CurrentValueNamePair.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    currentValue = json['current_value'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    return {
      'current_value': currentValue,
      'name': name
     };
  }

  static List<CurrentValueNamePair> listFromJson(List<dynamic> json) {
    return json == null ? new List<CurrentValueNamePair>() : json.map((value) => new CurrentValueNamePair.fromJson(value)).toList();
  }

  static Map<String, CurrentValueNamePair> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, CurrentValueNamePair>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new CurrentValueNamePair.fromJson(value));
    }
    return map;
  }
}
