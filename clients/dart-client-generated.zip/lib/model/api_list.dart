part of swagger.api;

class ApiList {
  
  ApiList();

  @override
  String toString() {
    return 'ApiList[]';
  }

  ApiList.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
  }

  Map<String, dynamic> toJson() {
    return {
     };
  }

  static List<ApiList> listFromJson(List<dynamic> json) {
    return json == null ? new List<ApiList>() : json.map((value) => new ApiList.fromJson(value)).toList();
  }

  static Map<String, ApiList> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, ApiList>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new ApiList.fromJson(value));
    }
    return map;
  }
}
