part of swagger.api;

class CurrentFeaturesList {
  
  List<String> functions = [];

  CurrentFeaturesList();

  @override
  String toString() {
    return 'CurrentFeaturesList[functions=$functions, ]';
  }

  CurrentFeaturesList.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    functions = (json['functions'] as List).map((item) => item as String).toList();
  }

  Map<String, dynamic> toJson() {
    return {
      'functions': functions
     };
  }

  static List<CurrentFeaturesList> listFromJson(List<dynamic> json) {
    return json == null ? new List<CurrentFeaturesList>() : json.map((value) => new CurrentFeaturesList.fromJson(value)).toList();
  }

  static Map<String, CurrentFeaturesList> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, CurrentFeaturesList>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new CurrentFeaturesList.fromJson(value));
    }
    return map;
  }
}
