part of swagger.api;

class WarningStatusList {
  
  List<String> warnings = [];

  WarningStatusList();

  @override
  String toString() {
    return 'WarningStatusList[warnings=$warnings, ]';
  }

  WarningStatusList.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    warnings = (json['warnings'] as List).map((item) => item as String).toList();
  }

  Map<String, dynamic> toJson() {
    return {
      'warnings': warnings
     };
  }

  static List<WarningStatusList> listFromJson(List<dynamic> json) {
    return json == null ? new List<WarningStatusList>() : json.map((value) => new WarningStatusList.fromJson(value)).toList();
  }

  static Map<String, WarningStatusList> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, WarningStatusList>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new WarningStatusList.fromJson(value));
    }
    return map;
  }
}
