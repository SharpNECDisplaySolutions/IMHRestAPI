part of swagger.api;

class OneOfinlineResponse200 {
  
  OneOfinlineResponse200();

  @override
  String toString() {
    return 'OneOfinlineResponse200[]';
  }

  OneOfinlineResponse200.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
  }

  Map<String, dynamic> toJson() {
    return {
     };
  }

  static List<OneOfinlineResponse200> listFromJson(List<dynamic> json) {
    return json == null ? new List<OneOfinlineResponse200>() : json.map((value) => new OneOfinlineResponse200.fromJson(value)).toList();
  }

  static Map<String, OneOfinlineResponse200> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, OneOfinlineResponse200>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new OneOfinlineResponse200.fromJson(value));
    }
    return map;
  }
}
