part of swagger.api;

class CurrentWarningStatus {
  /* Warning code of the display */
  String warning = null;
/* Warning ID */
  String id = null;
/* Detail.  Note this field may or may not be present */
  String detail = null;

  CurrentWarningStatus();

  @override
  String toString() {
    return 'CurrentWarningStatus[warning=$warning, id=$id, detail=$detail, ]';
  }

  CurrentWarningStatus.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    warning = json['warning'];
    id = json['id'];
    detail = json['detail'];
  }

  Map<String, dynamic> toJson() {
    return {
      'warning': warning,
      'id': id,
      'detail': detail
     };
  }

  static List<CurrentWarningStatus> listFromJson(List<dynamic> json) {
    return json == null ? new List<CurrentWarningStatus>() : json.map((value) => new CurrentWarningStatus.fromJson(value)).toList();
  }

  static Map<String, CurrentWarningStatus> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, CurrentWarningStatus>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new CurrentWarningStatus.fromJson(value));
    }
    return map;
  }
}
