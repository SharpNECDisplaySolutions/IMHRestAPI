part of swagger.api;

class KeyNameList {
  
  KeyNameList();

  @override
  String toString() {
    return 'KeyNameList[]';
  }

  KeyNameList.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
  }

  Map<String, dynamic> toJson() {
    return {
     };
  }

  static List<KeyNameList> listFromJson(List<dynamic> json) {
    return json == null ? new List<KeyNameList>() : json.map((value) => new KeyNameList.fromJson(value)).toList();
  }

  static Map<String, KeyNameList> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, KeyNameList>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new KeyNameList.fromJson(value));
    }
    return map;
  }
}
