part of swagger.api;

class ErrorValue {
  /* Specific error */
  int error = null;

  ErrorValue();

  @override
  String toString() {
    return 'ErrorValue[error=$error, ]';
  }

  ErrorValue.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    error = json['error'];
  }

  Map<String, dynamic> toJson() {
    return {
      'error': error
     };
  }

  static List<ErrorValue> listFromJson(List<dynamic> json) {
    return json == null ? new List<ErrorValue>() : json.map((value) => new ErrorValue.fromJson(value)).toList();
  }

  static Map<String, ErrorValue> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, ErrorValue>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new ErrorValue.fromJson(value));
    }
    return map;
  }
}
