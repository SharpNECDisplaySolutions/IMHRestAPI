part of swagger.api;

class CurrentBoolValue {
  
  bool currentValue = null;

  CurrentBoolValue();

  @override
  String toString() {
    return 'CurrentBoolValue[currentValue=$currentValue, ]';
  }

  CurrentBoolValue.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    currentValue = json['current_value'];
  }

  Map<String, dynamic> toJson() {
    return {
      'current_value': currentValue
     };
  }

  static List<CurrentBoolValue> listFromJson(List<dynamic> json) {
    return json == null ? new List<CurrentBoolValue>() : json.map((value) => new CurrentBoolValue.fromJson(value)).toList();
  }

  static Map<String, CurrentBoolValue> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, CurrentBoolValue>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new CurrentBoolValue.fromJson(value));
    }
    return map;
  }
}
