part of swagger.api;

class OneOfinlineResponse2003 {
  
  OneOfinlineResponse2003();

  @override
  String toString() {
    return 'OneOfinlineResponse2003[]';
  }

  OneOfinlineResponse2003.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
  }

  Map<String, dynamic> toJson() {
    return {
     };
  }

  static List<OneOfinlineResponse2003> listFromJson(List<dynamic> json) {
    return json == null ? new List<OneOfinlineResponse2003>() : json.map((value) => new OneOfinlineResponse2003.fromJson(value)).toList();
  }

  static Map<String, OneOfinlineResponse2003> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, OneOfinlineResponse2003>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new OneOfinlineResponse2003.fromJson(value));
    }
    return map;
  }
}
