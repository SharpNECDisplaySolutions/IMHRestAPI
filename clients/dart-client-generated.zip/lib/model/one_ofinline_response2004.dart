part of swagger.api;

class OneOfinlineResponse2004 {
  
  OneOfinlineResponse2004();

  @override
  String toString() {
    return 'OneOfinlineResponse2004[]';
  }

  OneOfinlineResponse2004.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
  }

  Map<String, dynamic> toJson() {
    return {
     };
  }

  static List<OneOfinlineResponse2004> listFromJson(List<dynamic> json) {
    return json == null ? new List<OneOfinlineResponse2004>() : json.map((value) => new OneOfinlineResponse2004.fromJson(value)).toList();
  }

  static Map<String, OneOfinlineResponse2004> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, OneOfinlineResponse2004>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new OneOfinlineResponse2004.fromJson(value));
    }
    return map;
  }
}
