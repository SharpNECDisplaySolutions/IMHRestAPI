part of swagger.api;

class CurrentStringValue {
  
  String currentValue = null;

  CurrentStringValue();

  @override
  String toString() {
    return 'CurrentStringValue[currentValue=$currentValue, ]';
  }

  CurrentStringValue.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    currentValue = json['current_value'];
  }

  Map<String, dynamic> toJson() {
    return {
      'current_value': currentValue
     };
  }

  static List<CurrentStringValue> listFromJson(List<dynamic> json) {
    return json == null ? new List<CurrentStringValue>() : json.map((value) => new CurrentStringValue.fromJson(value)).toList();
  }

  static Map<String, CurrentStringValue> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, CurrentStringValue>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new CurrentStringValue.fromJson(value));
    }
    return map;
  }
}
