part of swagger.api;

class OneOfinlineResponse2002 {
  
  OneOfinlineResponse2002();

  @override
  String toString() {
    return 'OneOfinlineResponse2002[]';
  }

  OneOfinlineResponse2002.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
  }

  Map<String, dynamic> toJson() {
    return {
     };
  }

  static List<OneOfinlineResponse2002> listFromJson(List<dynamic> json) {
    return json == null ? new List<OneOfinlineResponse2002>() : json.map((value) => new OneOfinlineResponse2002.fromJson(value)).toList();
  }

  static Map<String, OneOfinlineResponse2002> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, OneOfinlineResponse2002>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new OneOfinlineResponse2002.fromJson(value));
    }
    return map;
  }
}
