part of swagger.api;

class ApiStatusList {
  
  ApiList elements = null;

  ApiStatusList();

  @override
  String toString() {
    return 'ApiStatusList[elements=$elements, ]';
  }

  ApiStatusList.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    elements = new ApiList.fromJson(json['elements']);
  }

  Map<String, dynamic> toJson() {
    return {
      'elements': elements
     };
  }

  static List<ApiStatusList> listFromJson(List<dynamic> json) {
    return json == null ? new List<ApiStatusList>() : json.map((value) => new ApiStatusList.fromJson(value)).toList();
  }

  static Map<String, ApiStatusList> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, ApiStatusList>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new ApiStatusList.fromJson(value));
    }
    return map;
  }
}
