part of swagger.api;

class ApiStatus {
  /* API version */
  String version = null;
/* Status of the version.  Statuses are stable, experimental or obsolete */
  String status = null;

  ApiStatus();

  @override
  String toString() {
    return 'ApiStatus[version=$version, status=$status, ]';
  }

  ApiStatus.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    version = json['version'];
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    return {
      'version': version,
      'status': status
     };
  }

  static List<ApiStatus> listFromJson(List<dynamic> json) {
    return json == null ? new List<ApiStatus>() : json.map((value) => new ApiStatus.fromJson(value)).toList();
  }

  static Map<String, ApiStatus> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, ApiStatus>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new ApiStatus.fromJson(value));
    }
    return map;
  }
}
