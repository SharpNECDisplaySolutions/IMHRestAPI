part of swagger.api;

class KeyNameListValue {
  
  KeyNameList elements = null;

  KeyNameListValue();

  @override
  String toString() {
    return 'KeyNameListValue[elements=$elements, ]';
  }

  KeyNameListValue.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    elements = new KeyNameList.fromJson(json['elements']);
  }

  Map<String, dynamic> toJson() {
    return {
      'elements': elements
     };
  }

  static List<KeyNameListValue> listFromJson(List<dynamic> json) {
    return json == null ? new List<KeyNameListValue>() : json.map((value) => new KeyNameListValue.fromJson(value)).toList();
  }

  static Map<String, KeyNameListValue> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, KeyNameListValue>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new KeyNameListValue.fromJson(value));
    }
    return map;
  }
}
