part of swagger.api;

class CurrentErrorStatus {
  /* Error code of the display */
  String error = null;
/* Error ID */
  String id = null;
/* Detail.  Note this field may or may not be present */
  String detail = null;

  CurrentErrorStatus();

  @override
  String toString() {
    return 'CurrentErrorStatus[error=$error, id=$id, detail=$detail, ]';
  }

  CurrentErrorStatus.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    error = json['error'];
    id = json['id'];
    detail = json['detail'];
  }

  Map<String, dynamic> toJson() {
    return {
      'error': error,
      'id': id,
      'detail': detail
     };
  }

  static List<CurrentErrorStatus> listFromJson(List<dynamic> json) {
    return json == null ? new List<CurrentErrorStatus>() : json.map((value) => new CurrentErrorStatus.fromJson(value)).toList();
  }

  static Map<String, CurrentErrorStatus> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, CurrentErrorStatus>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new CurrentErrorStatus.fromJson(value));
    }
    return map;
  }
}
