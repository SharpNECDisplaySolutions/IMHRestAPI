part of swagger.api;

class CurrentValueNameList {
  
  CurrentValueNameList();

  @override
  String toString() {
    return 'CurrentValueNameList[]';
  }

  CurrentValueNameList.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
  }

  Map<String, dynamic> toJson() {
    return {
     };
  }

  static List<CurrentValueNameList> listFromJson(List<dynamic> json) {
    return json == null ? new List<CurrentValueNameList>() : json.map((value) => new CurrentValueNameList.fromJson(value)).toList();
  }

  static Map<String, CurrentValueNameList> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, CurrentValueNameList>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new CurrentValueNameList.fromJson(value));
    }
    return map;
  }
}
