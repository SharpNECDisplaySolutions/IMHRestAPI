part of swagger.api;

class OneOfinlineResponse2008 {
  
  OneOfinlineResponse2008();

  @override
  String toString() {
    return 'OneOfinlineResponse2008[]';
  }

  OneOfinlineResponse2008.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
  }

  Map<String, dynamic> toJson() {
    return {
     };
  }

  static List<OneOfinlineResponse2008> listFromJson(List<dynamic> json) {
    return json == null ? new List<OneOfinlineResponse2008>() : json.map((value) => new OneOfinlineResponse2008.fromJson(value)).toList();
  }

  static Map<String, OneOfinlineResponse2008> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, OneOfinlineResponse2008>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new OneOfinlineResponse2008.fromJson(value));
    }
    return map;
  }
}
