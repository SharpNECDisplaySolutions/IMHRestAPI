# swagger.model.CurrentWarningStatus

## Load the model package
```dart
import 'package:swagger/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**warning** | **String** | Warning code of the display | [optional] [default to null]
**id** | **String** | Warning ID | [optional] [default to null]
**detail** | **String** | Detail.  Note this field may or may not be present | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

