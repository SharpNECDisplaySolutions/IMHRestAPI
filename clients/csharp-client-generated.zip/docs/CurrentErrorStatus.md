# IO.Swagger.Model.CurrentErrorStatus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Error** | **string** | Error code of the display | [optional] 
**Id** | **string** | Error ID | [optional] 
**Detail** | **string** | Detail.  Note this field may or may not be present | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

