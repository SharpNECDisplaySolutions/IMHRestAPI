# CurrentErrorStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **str** | Error code of the display | [optional] 
**id** | **str** | Error ID | [optional] 
**detail** | **str** | Detail.  Note this field may or may not be present | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

