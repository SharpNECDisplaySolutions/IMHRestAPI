# CurrentWarningStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**warning** | **str** | Warning code of the display | [optional] 
**id** | **str** | Warning ID | [optional] 
**detail** | **str** | Detail.  Note this field may or may not be present | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

