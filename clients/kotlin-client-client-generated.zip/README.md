# io.swagger.client - Kotlin client library for NEC Displays API

## Requires

* Kotlin 1.4.30
* Gradle 5.3

## Build

First, create the gradle wrapper script:

```
gradle wrapper
```

Then, run:

```
./gradlew check assemble
```

This runs all tests and packages the library.

## Features/Implementation Notes

* Supports JSON inputs/outputs, File inputs, and Form inputs.
* Supports collection formats for query parameters: csv, tsv, ssv, pipes.
* Some Kotlin and Java types are fully qualified to avoid conflicts with types defined in Swagger definitions.
* Implementation of ApiClient is intended to reduce method counts, specifically to benefit Android targets.

<a name="documentation-for-api-endpoints"></a>
## Documentation for API Endpoints

All URIs are relative to *http://{displayIp}/api/{version}*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*DefaultApi* | [**getAvmute**](docs/DefaultApi.md#getavmute) | **GET** /avmute | Get the Audio/Video mute status
*DefaultApi* | [**getBacklight**](docs/DefaultApi.md#getbacklight) | **GET** /backlight | Get the current backlight
*DefaultApi* | [**getBrightness**](docs/DefaultApi.md#getbrightness) | **GET** /brightness | Get the current brightness in relation to the background
*DefaultApi* | [**getColor**](docs/DefaultApi.md#getcolor) | **GET** /color | Get the current color
*DefaultApi* | [**getContrast**](docs/DefaultApi.md#getcontrast) | **GET** /contrast | Get the current contrast
*DefaultApi* | [**getErrorStatus**](docs/DefaultApi.md#geterrorstatus) | **GET** /error_status | Get the error status.
*DefaultApi* | [**getErrorStatusList**](docs/DefaultApi.md#geterrorstatuslist) | **GET** /error_status/list | Get a list of the error status names.
*DefaultApi* | [**getFreeze**](docs/DefaultApi.md#getfreeze) | **GET** /freeze | Get the current freeze
*DefaultApi* | [**getInput**](docs/DefaultApi.md#getinput) | **GET** /inputs | Gets current terminal input
*DefaultApi* | [**getInputList**](docs/DefaultApi.md#getinputlist) | **GET** /inputs/list | Returns the list of inputs by key-name pairs
*DefaultApi* | [**getModelName**](docs/DefaultApi.md#getmodelname) | **GET** /product_name | Get the model name of the display
*DefaultApi* | [**getPowerState**](docs/DefaultApi.md#getpowerstate) | **GET** /power | Get the power state
*DefaultApi* | [**getSharpness**](docs/DefaultApi.md#getsharpness) | **GET** /sharpness | Get the current sharpness
*DefaultApi* | [**getSupportedFeatures**](docs/DefaultApi.md#getsupportedfeatures) | **GET** /list | Get the API supported features
*DefaultApi* | [**getUsage**](docs/DefaultApi.md#getusage) | **GET** /usage | Get the usage status.
*DefaultApi* | [**getVolume**](docs/DefaultApi.md#getvolume) | **GET** /volume | Get the current volume
*DefaultApi* | [**getWarningStatus**](docs/DefaultApi.md#getwarningstatus) | **GET** /warning_status | Get the warning status.
*DefaultApi* | [**getWarningStatusList**](docs/DefaultApi.md#getwarningstatuslist) | **GET** /warning_status/list | Get a list of the warning status names
*DefaultApi* | [**putAvmute**](docs/DefaultApi.md#putavmute) | **PUT** /avmute | Set the Audio/Video mute status
*DefaultApi* | [**putBacklight**](docs/DefaultApi.md#putbacklight) | **PUT** /backlight | Set the current backlight. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
*DefaultApi* | [**putBrightness**](docs/DefaultApi.md#putbrightness) | **PUT** /brightness | Set the current brightness in relation to the background. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
*DefaultApi* | [**putColor**](docs/DefaultApi.md#putcolor) | **PUT** /color | Set the current color. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
*DefaultApi* | [**putContrast**](docs/DefaultApi.md#putcontrast) | **PUT** /contrast | Set the current contrast.  Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
*DefaultApi* | [**putFreeze**](docs/DefaultApi.md#putfreeze) | **PUT** /freeze | Set the current freeze.  0=Off, 1=On
*DefaultApi* | [**putInput**](docs/DefaultApi.md#putinput) | **PUT** /inputs | Switch the current input terminal
*DefaultApi* | [**putPowerState**](docs/DefaultApi.md#putpowerstate) | **PUT** /power | Set the power state.
*DefaultApi* | [**putSharpness**](docs/DefaultApi.md#putsharpness) | **PUT** /sharpness | Set the current sharpness. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
*DefaultApi* | [**putVolume**](docs/DefaultApi.md#putvolume) | **PUT** /volume | Set the current volume.  The range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

<a name="documentation-for-models"></a>
## Documentation for Models

 - [io.swagger.client.models.ApiList](docs/ApiList.md)
 - [io.swagger.client.models.ApiStatus](docs/ApiStatus.md)
 - [io.swagger.client.models.ApiStatusList](docs/ApiStatusList.md)
 - [io.swagger.client.models.CurrentBoolValue](docs/CurrentBoolValue.md)
 - [io.swagger.client.models.CurrentErrorStatus](docs/CurrentErrorStatus.md)
 - [io.swagger.client.models.CurrentFeaturesList](docs/CurrentFeaturesList.md)
 - [io.swagger.client.models.CurrentNumberValue](docs/CurrentNumberValue.md)
 - [io.swagger.client.models.CurrentStringValue](docs/CurrentStringValue.md)
 - [io.swagger.client.models.CurrentValueNameList](docs/CurrentValueNameList.md)
 - [io.swagger.client.models.CurrentValueNamePair](docs/CurrentValueNamePair.md)
 - [io.swagger.client.models.CurrentWarningStatus](docs/CurrentWarningStatus.md)
 - [io.swagger.client.models.ErrorStatusList](docs/ErrorStatusList.md)
 - [io.swagger.client.models.ErrorValue](docs/ErrorValue.md)
 - [io.swagger.client.models.InlineResponse200](docs/InlineResponse200.md)
 - [io.swagger.client.models.InlineResponse2001](docs/InlineResponse2001.md)
 - [io.swagger.client.models.InlineResponse2002](docs/InlineResponse2002.md)
 - [io.swagger.client.models.InlineResponse2003](docs/InlineResponse2003.md)
 - [io.swagger.client.models.InlineResponse2004](docs/InlineResponse2004.md)
 - [io.swagger.client.models.InlineResponse2005](docs/InlineResponse2005.md)
 - [io.swagger.client.models.InlineResponse2006](docs/InlineResponse2006.md)
 - [io.swagger.client.models.InlineResponse2007](docs/InlineResponse2007.md)
 - [io.swagger.client.models.InlineResponse2008](docs/InlineResponse2008.md)
 - [io.swagger.client.models.KeyNameList](docs/KeyNameList.md)
 - [io.swagger.client.models.KeyNameListValue](docs/KeyNameListValue.md)
 - [io.swagger.client.models.KeyNamePair](docs/KeyNamePair.md)
 - [io.swagger.client.models.OneOfinlineResponse200](docs/OneOfinlineResponse200.md)
 - [io.swagger.client.models.OneOfinlineResponse2001](docs/OneOfinlineResponse2001.md)
 - [io.swagger.client.models.OneOfinlineResponse2002](docs/OneOfinlineResponse2002.md)
 - [io.swagger.client.models.OneOfinlineResponse2003](docs/OneOfinlineResponse2003.md)
 - [io.swagger.client.models.OneOfinlineResponse2004](docs/OneOfinlineResponse2004.md)
 - [io.swagger.client.models.OneOfinlineResponse2005](docs/OneOfinlineResponse2005.md)
 - [io.swagger.client.models.OneOfinlineResponse2006](docs/OneOfinlineResponse2006.md)
 - [io.swagger.client.models.OneOfinlineResponse2007](docs/OneOfinlineResponse2007.md)
 - [io.swagger.client.models.OneOfinlineResponse2008](docs/OneOfinlineResponse2008.md)
 - [io.swagger.client.models.WarningStatusList](docs/WarningStatusList.md)

<a name="documentation-for-authorization"></a>
## Documentation for Authorization

All endpoints do not require authorization.
