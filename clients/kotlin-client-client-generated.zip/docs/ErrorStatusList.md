# ErrorStatusList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**kotlin.Array&lt;kotlin.String&gt;**](.md) |  |  [optional]
