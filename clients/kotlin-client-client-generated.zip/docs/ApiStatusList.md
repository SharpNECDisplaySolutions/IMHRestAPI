# ApiStatusList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**elements** | [**ApiList**](ApiList.md) |  |  [optional]
