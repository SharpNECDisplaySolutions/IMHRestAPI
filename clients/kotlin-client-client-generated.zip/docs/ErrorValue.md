# ErrorValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | [**kotlin.Int**](.md) | Specific error |  [optional]
