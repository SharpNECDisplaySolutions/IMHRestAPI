# CurrentBoolValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentValue** | [**kotlin.Boolean**](.md) |  |  [optional]
