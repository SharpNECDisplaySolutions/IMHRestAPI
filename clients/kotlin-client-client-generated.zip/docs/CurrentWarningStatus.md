# CurrentWarningStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**warning** | [**kotlin.String**](.md) | Warning code of the display |  [optional]
**id** | [**kotlin.String**](.md) | Warning ID |  [optional]
**detail** | [**kotlin.String**](.md) | Detail.  Note this field may or may not be present |  [optional]
