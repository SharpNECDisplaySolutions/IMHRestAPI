# CurrentStringValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentValue** | [**kotlin.String**](.md) |  |  [optional]
