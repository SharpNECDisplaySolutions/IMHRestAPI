# CurrentErrorStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | [**kotlin.String**](.md) | Error code of the display |  [optional]
**id** | [**kotlin.String**](.md) | Error ID |  [optional]
**detail** | [**kotlin.String**](.md) | Detail.  Note this field may or may not be present |  [optional]
