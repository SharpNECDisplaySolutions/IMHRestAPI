# CurrentNumberValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentValue** | [**kotlin.Int**](.md) |  |  [optional]
