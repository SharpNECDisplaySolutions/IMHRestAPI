# WarningStatusList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**warnings** | [**kotlin.Array&lt;kotlin.String&gt;**](.md) |  |  [optional]
