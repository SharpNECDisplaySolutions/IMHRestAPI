# OneOfinlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
