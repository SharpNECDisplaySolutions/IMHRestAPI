# KeyNamePair

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**kotlin.Int**](.md) |  |  [optional]
**name** | [**kotlin.String**](.md) |  |  [optional]
