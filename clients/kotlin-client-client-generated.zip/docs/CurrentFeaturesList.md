# CurrentFeaturesList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**functions** | [**kotlin.Array&lt;kotlin.String&gt;**](.md) |  |  [optional]
