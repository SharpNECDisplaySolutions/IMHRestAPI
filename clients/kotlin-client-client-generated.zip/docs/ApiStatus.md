# ApiStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | [**kotlin.String**](.md) | API version |  [optional]
**status** | [**kotlin.String**](.md) | Status of the version.  Statuses are stable, experimental or obsolete |  [optional]
