# CurrentValueNamePair

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentValue** | [**kotlin.Int**](.md) |  |  [optional]
**name** | [**kotlin.String**](.md) |  |  [optional]
