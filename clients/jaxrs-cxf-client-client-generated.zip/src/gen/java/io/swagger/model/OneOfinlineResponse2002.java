package io.swagger.model;


/**
* OneOfinlineResponse2002
*/
public interface OneOfinlineResponse2002 {

}
