package io.swagger.model;

import io.swagger.v3.oas.annotations.media.Schema;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

/**
  * Error returned from command.  No error=0, parameter error=-100, busy error=-200, unavailable error=-300
 **/
@Schema(description="Error returned from command.  No error=0, parameter error=-100, busy error=-200, unavailable error=-300")
public class ErrorValue  implements OneOfinlineResponse200, OneOfinlineResponse2001, OneOfinlineResponse2002, OneOfinlineResponse2003, OneOfinlineResponse2004, OneOfinlineResponse2005, OneOfinlineResponse2006, OneOfinlineResponse2007, OneOfinlineResponse2008  {
  
  @Schema(description = "Specific error")
 /**
   * Specific error  
  **/
  private Integer error = null;
 /**
   * Specific error
   * @return error
  **/
  @JsonProperty("error")
  public Integer getError() {
    return error;
  }

  public void setError(Integer error) {
    this.error = error;
  }

  public ErrorValue error(Integer error) {
    this.error = error;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ErrorValue {\n");
    
    sb.append("    error: ").append(toIndentedString(error)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
