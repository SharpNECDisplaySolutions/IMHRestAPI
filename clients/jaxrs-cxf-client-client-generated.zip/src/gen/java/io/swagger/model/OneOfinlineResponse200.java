package io.swagger.model;


/**
* OneOfinlineResponse200
*/
public interface OneOfinlineResponse200 {

}
