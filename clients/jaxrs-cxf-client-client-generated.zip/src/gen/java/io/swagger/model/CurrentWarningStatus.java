package io.swagger.model;

import io.swagger.v3.oas.annotations.media.Schema;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

/**
  * Current warning status of the display.  none=Normal with no errors, light=Light source replacement grace period, filter=Filter cleaning time exceeded.
 **/
@Schema(description="Current warning status of the display.  none=Normal with no errors, light=Light source replacement grace period, filter=Filter cleaning time exceeded.")
public class CurrentWarningStatus  implements OneOfinlineResponse2005  {
  
  @Schema(description = "Warning code of the display")
 /**
   * Warning code of the display  
  **/
  private String warning = null;
  
  @Schema(description = "Warning ID")
 /**
   * Warning ID  
  **/
  private String id = null;
  
  @Schema(description = "Detail.  Note this field may or may not be present")
 /**
   * Detail.  Note this field may or may not be present  
  **/
  private String detail = null;
 /**
   * Warning code of the display
   * @return warning
  **/
  @JsonProperty("warning")
  public String getWarning() {
    return warning;
  }

  public void setWarning(String warning) {
    this.warning = warning;
  }

  public CurrentWarningStatus warning(String warning) {
    this.warning = warning;
    return this;
  }

 /**
   * Warning ID
   * @return id
  **/
  @JsonProperty("id")
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public CurrentWarningStatus id(String id) {
    this.id = id;
    return this;
  }

 /**
   * Detail.  Note this field may or may not be present
   * @return detail
  **/
  @JsonProperty("detail")
  public String getDetail() {
    return detail;
  }

  public void setDetail(String detail) {
    this.detail = detail;
  }

  public CurrentWarningStatus detail(String detail) {
    this.detail = detail;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CurrentWarningStatus {\n");
    
    sb.append("    warning: ").append(toIndentedString(warning)).append("\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    detail: ").append(toIndentedString(detail)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
