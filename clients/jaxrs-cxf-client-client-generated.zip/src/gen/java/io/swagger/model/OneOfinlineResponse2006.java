package io.swagger.model;


/**
* OneOfinlineResponse2006
*/
public interface OneOfinlineResponse2006 {

}
