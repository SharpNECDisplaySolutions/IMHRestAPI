package io.swagger.model;

import io.swagger.v3.oas.annotations.media.Schema;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

/**
  * Current error status of the display.  none=Normal with no errors, cover=Abonormal cover, lens=without lens, temperature=abnormal temp fan=abnormal fan, light=Light source or backlight not lit or light source usage time exceeded, system=System error,  power=abnormal power
 **/
@Schema(description="Current error status of the display.  none=Normal with no errors, cover=Abonormal cover, lens=without lens, temperature=abnormal temp fan=abnormal fan, light=Light source or backlight not lit or light source usage time exceeded, system=System error,  power=abnormal power")
public class CurrentErrorStatus  implements OneOfinlineResponse2004  {
  
  @Schema(description = "Error code of the display")
 /**
   * Error code of the display  
  **/
  private String error = null;
  
  @Schema(description = "Error ID")
 /**
   * Error ID  
  **/
  private String id = null;
  
  @Schema(description = "Detail.  Note this field may or may not be present")
 /**
   * Detail.  Note this field may or may not be present  
  **/
  private String detail = null;
 /**
   * Error code of the display
   * @return error
  **/
  @JsonProperty("error")
  public String getError() {
    return error;
  }

  public void setError(String error) {
    this.error = error;
  }

  public CurrentErrorStatus error(String error) {
    this.error = error;
    return this;
  }

 /**
   * Error ID
   * @return id
  **/
  @JsonProperty("id")
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public CurrentErrorStatus id(String id) {
    this.id = id;
    return this;
  }

 /**
   * Detail.  Note this field may or may not be present
   * @return detail
  **/
  @JsonProperty("detail")
  public String getDetail() {
    return detail;
  }

  public void setDetail(String detail) {
    this.detail = detail;
  }

  public CurrentErrorStatus detail(String detail) {
    this.detail = detail;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CurrentErrorStatus {\n");
    
    sb.append("    error: ").append(toIndentedString(error)).append("\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    detail: ").append(toIndentedString(detail)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
