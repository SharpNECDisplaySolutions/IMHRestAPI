package io.swagger.model;


/**
* OneOfinlineResponse2001
*/
public interface OneOfinlineResponse2001 {

}
