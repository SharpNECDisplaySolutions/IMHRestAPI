package io.swagger.model;


/**
* OneOfinlineResponse2003
*/
public interface OneOfinlineResponse2003 {

}
