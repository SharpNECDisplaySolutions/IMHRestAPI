package io.swagger.model;


/**
* OneOfinlineResponse2004
*/
public interface OneOfinlineResponse2004 {

}
