package io.swagger.model;


/**
* OneOfinlineResponse2007
*/
public interface OneOfinlineResponse2007 {

}
