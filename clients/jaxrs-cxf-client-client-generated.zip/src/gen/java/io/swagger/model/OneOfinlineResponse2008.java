package io.swagger.model;


/**
* OneOfinlineResponse2008
*/
public interface OneOfinlineResponse2008 {

}
