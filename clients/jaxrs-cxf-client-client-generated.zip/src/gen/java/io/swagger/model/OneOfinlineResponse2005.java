package io.swagger.model;


/**
* OneOfinlineResponse2005
*/
public interface OneOfinlineResponse2005 {

}
