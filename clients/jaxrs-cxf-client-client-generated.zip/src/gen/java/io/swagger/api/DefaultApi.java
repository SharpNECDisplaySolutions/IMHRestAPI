package io.swagger.api;

import io.swagger.model.ErrorValue;
import io.swagger.model.InlineResponse200;
import io.swagger.model.InlineResponse2001;
import io.swagger.model.InlineResponse2002;
import io.swagger.model.InlineResponse2003;
import io.swagger.model.InlineResponse2004;
import io.swagger.model.InlineResponse2005;
import io.swagger.model.InlineResponse2006;
import io.swagger.model.InlineResponse2007;
import io.swagger.model.InlineResponse2008;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * NEC Displays API
 *
 * <p>Sharp NEC Display Solutions Displays API. This API defines the interface available to external applications for NEC displays. Models supported are  MA491, MA551, P435, P495, and P555.  Newer models not listed may be supported.
 *
 */
@Path("/")
public interface DefaultApi  {

    /**
     * Get the Audio/Video mute status
     *
     */
    @GET
    @Path("/avmute")
    @Produces({ "application/json" })
    @Operation(summary = "Get the Audio/Video mute status", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  The current value of avmute is returned. 0 Video and Audio mute OFF, 1 Video mute on, 2 Audio mute on,  3 Video and audio mute on", content = @Content(schema = @Schema(implementation = InlineResponse200.class))) })
    public InlineResponse200 getAvmute();

    /**
     * Get the current backlight
     *
     */
    @GET
    @Path("/backlight")
    @Produces({ "application/json" })
    @Operation(summary = "Get the current backlight", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  Return the current backlight.  Range is 0-100.", content = @Content(schema = @Schema(implementation = InlineResponse200.class))) })
    public InlineResponse200 getBacklight();

    /**
     * Get the current brightness in relation to the background
     *
     */
    @GET
    @Path("/brightness")
    @Produces({ "application/json" })
    @Operation(summary = "Get the current brightness in relation to the background", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  Return the current brightness.  Range is 0-100.", content = @Content(schema = @Schema(implementation = InlineResponse200.class))) })
    public InlineResponse200 getBrightness();

    /**
     * Get the current color
     *
     */
    @GET
    @Path("/color")
    @Produces({ "application/json" })
    @Operation(summary = "Get the current color", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  Return the current color.  Range is 0-100.", content = @Content(schema = @Schema(implementation = InlineResponse200.class))) })
    public InlineResponse200 getColor();

    /**
     * Get the current contrast
     *
     */
    @GET
    @Path("/contrast")
    @Produces({ "application/json" })
    @Operation(summary = "Get the current contrast", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  Return the current contrast. Range is 0-100.", content = @Content(schema = @Schema(implementation = InlineResponse200.class))) })
    public InlineResponse200 getContrast();

    /**
     * Get the error status.
     *
     */
    @GET
    @Path("/error_status")
    @Produces({ "application/json" })
    @Operation(summary = "Get the error status.", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  Current error status of the display.  none=Normal with no errors, cover=Abonormal cover, lens=without lens, temperature=abnormal temp,fan=abnormal fan, light=Light source or backlight not lit or light source usage time exceeded, system=System error, power=abnormal power", content = @Content(schema = @Schema(implementation = InlineResponse2004.class))) })
    public InlineResponse2004 getErrorStatus();

    /**
     * Get a list of the error status names.
     *
     */
    @GET
    @Path("/error_status/list")
    @Produces({ "application/json" })
    @Operation(summary = "Get a list of the error status names.", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  List of error status names", content = @Content(schema = @Schema(implementation = InlineResponse2006.class))) })
    public InlineResponse2006 getErrorStatusList();

    /**
     * Get the current freeze
     *
     */
    @GET
    @Path("/freeze")
    @Produces({ "application/json" })
    @Operation(summary = "Get the current freeze", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  Return the current freeze. 0=off, 1=on", content = @Content(schema = @Schema(implementation = InlineResponse200.class))) })
    public InlineResponse200 getFreeze();

    /**
     * Gets current terminal input
     *
     */
    @GET
    @Path("/inputs")
    @Produces({ "application/json" })
    @Operation(summary = "Gets current terminal input", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  The current value of the input is returned.  Note that before calling this, call inputs/list to get a list of the input values and names.  Sample inputs are 1=HDMI1, 2=HDMI2, and 11=DisplayPort", content = @Content(schema = @Schema(implementation = InlineResponse200.class))) })
    public InlineResponse200 getInput();

    /**
     * Returns the list of inputs by key-name pairs
     *
     */
    @GET
    @Path("/inputs/list")
    @Produces({ "application/json" })
    @Operation(summary = "Returns the list of inputs by key-name pairs", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Return is OK even if an error occurred.  Check for error value.", content = @Content(schema = @Schema(implementation = InlineResponse2001.class))) })
    public InlineResponse2001 getInputList();

    /**
     * Get the model name of the display
     *
     */
    @GET
    @Path("/product_name")
    @Produces({ "application/json" })
    @Operation(summary = "Get the model name of the display", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  The current value of model name is returned.", content = @Content(schema = @Schema(implementation = InlineResponse2002.class))) })
    public InlineResponse2002 getModelName();

    /**
     * Get the power state
     *
     */
    @GET
    @Path("/power")
    @Produces({ "application/json" })
    @Operation(summary = "Get the power state", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  The power state is returned.  0=off, 1=on and 2=power saving (read-only)", content = @Content(schema = @Schema(implementation = InlineResponse200.class))) })
    public InlineResponse200 getPowerState();

    /**
     * Get the current sharpness
     *
     */
    @GET
    @Path("/sharpness")
    @Produces({ "application/json" })
    @Operation(summary = "Get the current sharpness", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  Return the current sharpness. Range is 0-100.", content = @Content(schema = @Schema(implementation = InlineResponse200.class))) })
    public InlineResponse200 getSharpness();

    /**
     * Get the API supported features
     *
     */
    @GET
    @Path("/list")
    @Produces({ "application/json" })
    @Operation(summary = "Get the API supported features", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  Return the supported features list for each api version.", content = @Content(schema = @Schema(implementation = InlineResponse2008.class))) })
    public InlineResponse2008 getSupportedFeatures();

    /**
     * Get the usage status.
     *
     */
    @GET
    @Path("/usage")
    @Produces({ "application/json" })
    @Operation(summary = "Get the usage status.", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  Returns an array of usage elements, sucha as light hours used and filter hours used.   Units returned are H (hours).  Whether minutes or seconds are rounded off or rounded down depends on the model.", content = @Content(schema = @Schema(implementation = InlineResponse2003.class))) })
    public InlineResponse2003 getUsage();

    /**
     * Get the current volume
     *
     */
    @GET
    @Path("/volume")
    @Produces({ "application/json" })
    @Operation(summary = "Get the current volume", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  Return the current volume. Range is 0-100.", content = @Content(schema = @Schema(implementation = InlineResponse200.class))) })
    public InlineResponse200 getVolume();

    /**
     * Get the warning status.
     *
     */
    @GET
    @Path("/warning_status")
    @Produces({ "application/json" })
    @Operation(summary = "Get the warning status.", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  Current warning status of the display.  none=Normal with no errors, light=Light source replacement grace period, filter=Filter cleaning time exceeded.", content = @Content(schema = @Schema(implementation = InlineResponse2005.class))) })
    public InlineResponse2005 getWarningStatus();

    /**
     * Get a list of the warning status names
     *
     */
    @GET
    @Path("/warning_status/list")
    @Produces({ "application/json" })
    @Operation(summary = "Get a list of the warning status names", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Success.  List of warning status names", content = @Content(schema = @Schema(implementation = InlineResponse2007.class))) })
    public InlineResponse2007 getWarningStatusList();

    /**
     * Set the Audio/Video mute status
     *
     */
    @PUT
    @Path("/avmute")
    @Produces({ "application/json" })
    @Operation(summary = "Set the Audio/Video mute status", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Return is OK even if an error occurred. Check for error value", content = @Content(schema = @Schema(implementation = ErrorValue.class))) })
    public ErrorValue putAvmute(@QueryParam("value")Integer value);

    /**
     * Set the current backlight. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
     *
     */
    @PUT
    @Path("/backlight")
    @Produces({ "application/json" })
    @Operation(summary = "Set the current backlight. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Return is OK even if an error occurred.  Check the error value.", content = @Content(schema = @Schema(implementation = ErrorValue.class))) })
    public ErrorValue putBacklight(@QueryParam("value")String value);

    /**
     * Set the current brightness in relation to the background. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
     *
     */
    @PUT
    @Path("/brightness")
    @Produces({ "application/json" })
    @Operation(summary = "Set the current brightness in relation to the background. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Return is OK even if an error occurred.  Check the error value.", content = @Content(schema = @Schema(implementation = ErrorValue.class))) })
    public ErrorValue putBrightness(@QueryParam("value")String value);

    /**
     * Set the current color. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
     *
     */
    @PUT
    @Path("/color")
    @Produces({ "application/json" })
    @Operation(summary = "Set the current color. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Return is OK even if an error occurred.  Check the error value.", content = @Content(schema = @Schema(implementation = ErrorValue.class))) })
    public ErrorValue putColor(@QueryParam("value")String value);

    /**
     * Set the current contrast.  Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
     *
     */
    @PUT
    @Path("/contrast")
    @Produces({ "application/json" })
    @Operation(summary = "Set the current contrast.  Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Return is OK even if an error occurred.  Check the error value.", content = @Content(schema = @Schema(implementation = ErrorValue.class))) })
    public ErrorValue putContrast(@QueryParam("value")String value);

    /**
     * Set the current freeze.  0&#x3D;Off, 1&#x3D;On
     *
     */
    @PUT
    @Path("/freeze")
    @Produces({ "application/json" })
    @Operation(summary = "Set the current freeze.  0=Off, 1=On", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Return is OK even if an error occurred.  Check the error value.", content = @Content(schema = @Schema(implementation = ErrorValue.class))) })
    public ErrorValue putFreeze(@QueryParam("value")Integer value);

    /**
     * Switch the current input terminal
     *
     */
    @PUT
    @Path("/inputs")
    @Produces({ "application/json" })
    @Operation(summary = "Switch the current input terminal", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Return is OK even if an error occurred.  Check the error value.", content = @Content(schema = @Schema(implementation = ErrorValue.class))) })
    public ErrorValue putInput(@QueryParam("value")Integer value);

    /**
     * Set the power state.
     *
     */
    @PUT
    @Path("/power")
    @Produces({ "application/json" })
    @Operation(summary = "Set the power state.", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Return is OK even if an error occured.  Check for  error value.", content = @Content(schema = @Schema(implementation = ErrorValue.class))) })
    public ErrorValue putPowerState(@QueryParam("value")Integer value);

    /**
     * Set the current sharpness. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
     *
     */
    @PUT
    @Path("/sharpness")
    @Produces({ "application/json" })
    @Operation(summary = "Set the current sharpness. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Return is OK even if an error occurred.  Check the error value.", content = @Content(schema = @Schema(implementation = ErrorValue.class))) })
    public ErrorValue putSharpness(@QueryParam("value")String value);

    /**
     * Set the current volume.  The range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
     *
     */
    @PUT
    @Path("/volume")
    @Produces({ "application/json" })
    @Operation(summary = "Set the current volume.  The range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. --X    Change the current value to current_value - X.  If there is a -- sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Return is OK even if an error occurred.  Check the error value.", content = @Content(schema = @Schema(implementation = ErrorValue.class))) })
    public ErrorValue putVolume(@QueryParam("value")String value);
}
