# CurrentValueNamePair

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentValue** | **Integer** |  |  [optional]
**name** | **String** |  |  [optional]
