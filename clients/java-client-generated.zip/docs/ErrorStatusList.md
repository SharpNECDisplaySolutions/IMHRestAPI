# ErrorStatusList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | **List&lt;String&gt;** |  |  [optional]
