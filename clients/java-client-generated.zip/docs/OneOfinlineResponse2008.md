# OneOfinlineResponse2008

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
