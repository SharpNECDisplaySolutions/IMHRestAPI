# CurrentBoolValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentValue** | **Boolean** |  |  [optional]
