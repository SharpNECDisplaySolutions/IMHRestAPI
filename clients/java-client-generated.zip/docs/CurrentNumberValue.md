# CurrentNumberValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentValue** | **Integer** |  |  [optional]
