# CurrentFeaturesList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**functions** | **List&lt;String&gt;** |  |  [optional]
