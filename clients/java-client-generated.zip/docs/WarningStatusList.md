# WarningStatusList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**warnings** | **List&lt;String&gt;** |  |  [optional]
