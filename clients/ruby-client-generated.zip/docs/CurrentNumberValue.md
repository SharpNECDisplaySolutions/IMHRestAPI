# SwaggerClient::CurrentNumberValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**current_value** | **Integer** |  | [optional] 

