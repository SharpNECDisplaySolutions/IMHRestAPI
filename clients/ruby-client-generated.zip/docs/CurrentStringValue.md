# SwaggerClient::CurrentStringValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**current_value** | **String** |  | [optional] 

