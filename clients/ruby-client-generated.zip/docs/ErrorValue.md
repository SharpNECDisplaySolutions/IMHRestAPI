# SwaggerClient::ErrorValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **Integer** | Specific error | [optional] 

