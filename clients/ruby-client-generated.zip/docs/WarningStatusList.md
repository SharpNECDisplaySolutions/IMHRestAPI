# SwaggerClient::WarningStatusList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**warnings** | **Array&lt;String&gt;** |  | [optional] 

