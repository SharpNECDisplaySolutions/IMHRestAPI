# SwaggerClient::CurrentErrorStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** | Error code of the display | [optional] 
**id** | **String** | Error ID | [optional] 
**detail** | **String** | Detail.  Note this field may or may not be present | [optional] 

