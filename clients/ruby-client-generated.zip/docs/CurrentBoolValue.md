# SwaggerClient::CurrentBoolValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**current_value** | **BOOLEAN** |  | [optional] 

