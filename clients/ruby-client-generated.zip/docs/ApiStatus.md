# SwaggerClient::ApiStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **String** | API version | [optional] 
**status** | **String** | Status of the version.  Statuses are stable, experimental or obsolete | [optional] 

