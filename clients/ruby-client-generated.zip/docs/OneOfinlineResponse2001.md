# SwaggerClient::OneOfinlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

