# SwaggerClient::OneOfinlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

