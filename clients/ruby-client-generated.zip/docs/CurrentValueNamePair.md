# SwaggerClient::CurrentValueNamePair

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**current_value** | **Integer** |  | [optional] 
**name** | **String** |  | [optional] 

