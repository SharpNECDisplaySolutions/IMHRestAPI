# SwaggerClient::InlineResponse2008

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

