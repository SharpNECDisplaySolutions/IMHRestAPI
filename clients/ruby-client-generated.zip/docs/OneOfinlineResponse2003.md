# SwaggerClient::OneOfinlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

