# SwaggerClient::CurrentWarningStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**warning** | **String** | Warning code of the display | [optional] 
**id** | **String** | Warning ID | [optional] 
**detail** | **String** | Detail.  Note this field may or may not be present | [optional] 

