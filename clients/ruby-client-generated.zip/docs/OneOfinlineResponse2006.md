# SwaggerClient::OneOfinlineResponse2006

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

