# SwaggerClient::CurrentFeaturesList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**functions** | **Array&lt;String&gt;** |  | [optional] 

