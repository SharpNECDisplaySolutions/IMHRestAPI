using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// Current error status of the display.  none&#x3D;Normal with no errors, cover&#x3D;Abonormal cover, lens&#x3D;without lens, temperature&#x3D;abnormal temp fan&#x3D;abnormal fan, light&#x3D;Light source or backlight not lit or light source usage time exceeded, system&#x3D;System error,  power&#x3D;abnormal power
  /// </summary>
  [DataContract]
  public class CurrentErrorStatus {
    /// <summary>
    /// Error code of the display
    /// </summary>
    /// <value>Error code of the display</value>
    [DataMember(Name="error", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "error")]
    public string Error { get; set; }

    /// <summary>
    /// Error ID
    /// </summary>
    /// <value>Error ID</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public string Id { get; set; }

    /// <summary>
    /// Detail.  Note this field may or may not be present
    /// </summary>
    /// <value>Detail.  Note this field may or may not be present</value>
    [DataMember(Name="detail", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "detail")]
    public string Detail { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class CurrentErrorStatus {\n");
      sb.Append("  Error: ").Append(Error).Append("\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Detail: ").Append(Detail).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
