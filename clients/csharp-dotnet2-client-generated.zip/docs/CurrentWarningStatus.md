# IO.Swagger.Model.CurrentWarningStatus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Warning** | **string** | Warning code of the display | [optional] 
**Id** | **string** | Warning ID | [optional] 
**Detail** | **string** | Detail.  Note this field may or may not be present | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

