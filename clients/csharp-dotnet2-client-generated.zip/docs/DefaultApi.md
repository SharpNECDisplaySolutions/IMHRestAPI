# IO.Swagger.Api.DefaultApi

All URIs are relative to *http://{displayIp}/api/{version}*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetAvmute**](DefaultApi.md#getavmute) | **GET** /avmute | Get the Audio/Video mute status
[**GetBacklight**](DefaultApi.md#getbacklight) | **GET** /backlight | Get the current backlight
[**GetBrightness**](DefaultApi.md#getbrightness) | **GET** /brightness | Get the current brightness in relation to the background
[**GetColor**](DefaultApi.md#getcolor) | **GET** /color | Get the current color
[**GetContrast**](DefaultApi.md#getcontrast) | **GET** /contrast | Get the current contrast
[**GetErrorStatus**](DefaultApi.md#geterrorstatus) | **GET** /error_status | Get the error status.
[**GetErrorStatusList**](DefaultApi.md#geterrorstatuslist) | **GET** /error_status/list | Get a list of the error status names.
[**GetFreeze**](DefaultApi.md#getfreeze) | **GET** /freeze | Get the current freeze
[**GetInput**](DefaultApi.md#getinput) | **GET** /inputs | Gets current terminal input
[**GetInputList**](DefaultApi.md#getinputlist) | **GET** /inputs/list | Returns the list of inputs by key-name pairs
[**GetModelName**](DefaultApi.md#getmodelname) | **GET** /product_name | Get the model name of the display
[**GetPowerState**](DefaultApi.md#getpowerstate) | **GET** /power | Get the power state
[**GetSharpness**](DefaultApi.md#getsharpness) | **GET** /sharpness | Get the current sharpness
[**GetSupportedFeatures**](DefaultApi.md#getsupportedfeatures) | **GET** /list | Get the API supported features
[**GetUsage**](DefaultApi.md#getusage) | **GET** /usage | Get the usage status.
[**GetVolume**](DefaultApi.md#getvolume) | **GET** /volume | Get the current volume
[**GetWarningStatus**](DefaultApi.md#getwarningstatus) | **GET** /warning_status | Get the warning status.
[**GetWarningStatusList**](DefaultApi.md#getwarningstatuslist) | **GET** /warning_status/list | Get a list of the warning status names
[**PutAvmute**](DefaultApi.md#putavmute) | **PUT** /avmute | Set the Audio/Video mute status
[**PutBacklight**](DefaultApi.md#putbacklight) | **PUT** /backlight | Set the current backlight. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**PutBrightness**](DefaultApi.md#putbrightness) | **PUT** /brightness | Set the current brightness in relation to the background. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**PutColor**](DefaultApi.md#putcolor) | **PUT** /color | Set the current color. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**PutContrast**](DefaultApi.md#putcontrast) | **PUT** /contrast | Set the current contrast.  Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**PutFreeze**](DefaultApi.md#putfreeze) | **PUT** /freeze | Set the current freeze.  0&#x3D;Off, 1&#x3D;On
[**PutInput**](DefaultApi.md#putinput) | **PUT** /inputs | Switch the current input terminal
[**PutPowerState**](DefaultApi.md#putpowerstate) | **PUT** /power | Set the power state.
[**PutSharpness**](DefaultApi.md#putsharpness) | **PUT** /sharpness | Set the current sharpness. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
[**PutVolume**](DefaultApi.md#putvolume) | **PUT** /volume | Set the current volume.  The range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

<a name="getavmute"></a>
# **GetAvmute**
> InlineResponse200 GetAvmute ()

Get the Audio/Video mute status

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAvmuteExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get the Audio/Video mute status
                InlineResponse200 result = apiInstance.GetAvmute();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetAvmute: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getbacklight"></a>
# **GetBacklight**
> InlineResponse200 GetBacklight ()

Get the current backlight

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetBacklightExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get the current backlight
                InlineResponse200 result = apiInstance.GetBacklight();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetBacklight: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getbrightness"></a>
# **GetBrightness**
> InlineResponse200 GetBrightness ()

Get the current brightness in relation to the background

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetBrightnessExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get the current brightness in relation to the background
                InlineResponse200 result = apiInstance.GetBrightness();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetBrightness: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcolor"></a>
# **GetColor**
> InlineResponse200 GetColor ()

Get the current color

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetColorExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get the current color
                InlineResponse200 result = apiInstance.GetColor();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetColor: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcontrast"></a>
# **GetContrast**
> InlineResponse200 GetContrast ()

Get the current contrast

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetContrastExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get the current contrast
                InlineResponse200 result = apiInstance.GetContrast();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetContrast: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="geterrorstatus"></a>
# **GetErrorStatus**
> InlineResponse2004 GetErrorStatus ()

Get the error status.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetErrorStatusExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get the error status.
                InlineResponse2004 result = apiInstance.GetErrorStatus();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetErrorStatus: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="geterrorstatuslist"></a>
# **GetErrorStatusList**
> InlineResponse2006 GetErrorStatusList ()

Get a list of the error status names.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetErrorStatusListExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get a list of the error status names.
                InlineResponse2006 result = apiInstance.GetErrorStatusList();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetErrorStatusList: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getfreeze"></a>
# **GetFreeze**
> InlineResponse200 GetFreeze ()

Get the current freeze

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetFreezeExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get the current freeze
                InlineResponse200 result = apiInstance.GetFreeze();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetFreeze: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getinput"></a>
# **GetInput**
> InlineResponse200 GetInput ()

Gets current terminal input

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetInputExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Gets current terminal input
                InlineResponse200 result = apiInstance.GetInput();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetInput: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getinputlist"></a>
# **GetInputList**
> InlineResponse2001 GetInputList ()

Returns the list of inputs by key-name pairs

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetInputListExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Returns the list of inputs by key-name pairs
                InlineResponse2001 result = apiInstance.GetInputList();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetInputList: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getmodelname"></a>
# **GetModelName**
> InlineResponse2002 GetModelName ()

Get the model name of the display

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetModelNameExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get the model name of the display
                InlineResponse2002 result = apiInstance.GetModelName();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetModelName: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getpowerstate"></a>
# **GetPowerState**
> InlineResponse200 GetPowerState ()

Get the power state

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPowerStateExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get the power state
                InlineResponse200 result = apiInstance.GetPowerState();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetPowerState: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getsharpness"></a>
# **GetSharpness**
> InlineResponse200 GetSharpness ()

Get the current sharpness

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetSharpnessExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get the current sharpness
                InlineResponse200 result = apiInstance.GetSharpness();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetSharpness: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getsupportedfeatures"></a>
# **GetSupportedFeatures**
> InlineResponse2008 GetSupportedFeatures ()

Get the API supported features

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetSupportedFeaturesExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get the API supported features
                InlineResponse2008 result = apiInstance.GetSupportedFeatures();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetSupportedFeatures: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2008**](InlineResponse2008.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getusage"></a>
# **GetUsage**
> InlineResponse2003 GetUsage ()

Get the usage status.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetUsageExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get the usage status.
                InlineResponse2003 result = apiInstance.GetUsage();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetUsage: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getvolume"></a>
# **GetVolume**
> InlineResponse200 GetVolume ()

Get the current volume

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetVolumeExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get the current volume
                InlineResponse200 result = apiInstance.GetVolume();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetVolume: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getwarningstatus"></a>
# **GetWarningStatus**
> InlineResponse2005 GetWarningStatus ()

Get the warning status.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetWarningStatusExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get the warning status.
                InlineResponse2005 result = apiInstance.GetWarningStatus();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetWarningStatus: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getwarningstatuslist"></a>
# **GetWarningStatusList**
> InlineResponse2007 GetWarningStatusList ()

Get a list of the warning status names

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetWarningStatusListExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();

            try
            {
                // Get a list of the warning status names
                InlineResponse2007 result = apiInstance.GetWarningStatusList();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.GetWarningStatusList: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2007**](InlineResponse2007.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="putavmute"></a>
# **PutAvmute**
> ErrorValue PutAvmute (int? value)

Set the Audio/Video mute status

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutAvmuteExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();
            var value = 56;  // int? | Value of 0 turns video and audio mute off, 1 turns video mute on, 2 turns audio mute on and 3 turns both video and audio mute on

            try
            {
                // Set the Audio/Video mute status
                ErrorValue result = apiInstance.PutAvmute(value);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.PutAvmute: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **int?**| Value of 0 turns video and audio mute off, 1 turns video mute on, 2 turns audio mute on and 3 turns both video and audio mute on | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="putbacklight"></a>
# **PutBacklight**
> ErrorValue PutBacklight (string value)

Set the current backlight. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutBacklightExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();
            var value = value_example;  // string | Change the backlight.  Range is 0-100.

            try
            {
                // Set the current backlight. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
                ErrorValue result = apiInstance.PutBacklight(value);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.PutBacklight: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **string**| Change the backlight.  Range is 0-100. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="putbrightness"></a>
# **PutBrightness**
> ErrorValue PutBrightness (string value)

Set the current brightness in relation to the background. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutBrightnessExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();
            var value = value_example;  // string | Change the brightness.  Range is 0-100

            try
            {
                // Set the current brightness in relation to the background. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
                ErrorValue result = apiInstance.PutBrightness(value);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.PutBrightness: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **string**| Change the brightness.  Range is 0-100 | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="putcolor"></a>
# **PutColor**
> ErrorValue PutColor (string value)

Set the current color. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutColorExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();
            var value = value_example;  // string | Change the color.  Range is 0-100.

            try
            {
                // Set the current color. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
                ErrorValue result = apiInstance.PutColor(value);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.PutColor: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **string**| Change the color.  Range is 0-100. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="putcontrast"></a>
# **PutContrast**
> ErrorValue PutContrast (string value)

Set the current contrast.  Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutContrastExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();
            var value = value_example;  // string | Change the contrast.  Range is 0-100.

            try
            {
                // Set the current contrast.  Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
                ErrorValue result = apiInstance.PutContrast(value);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.PutContrast: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **string**| Change the contrast.  Range is 0-100. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="putfreeze"></a>
# **PutFreeze**
> ErrorValue PutFreeze (int? value)

Set the current freeze.  0=Off, 1=On

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutFreezeExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();
            var value = 56;  // int? | Change the freeze.

            try
            {
                // Set the current freeze.  0=Off, 1=On
                ErrorValue result = apiInstance.PutFreeze(value);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.PutFreeze: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **int?**| Change the freeze. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="putinput"></a>
# **PutInput**
> ErrorValue PutInput (int? value)

Switch the current input terminal

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutInputExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();
            var value = 56;  // int? | Change the input.  Call inputs/list before this to get a list of valid inputs and names. Sample inputs are 1=HDMI1, 2=HDMI2, and 11=DisplayPort

            try
            {
                // Switch the current input terminal
                ErrorValue result = apiInstance.PutInput(value);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.PutInput: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **int?**| Change the input.  Call inputs/list before this to get a list of valid inputs and names. Sample inputs are 1&#x3D;HDMI1, 2&#x3D;HDMI2, and 11&#x3D;DisplayPort | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="putpowerstate"></a>
# **PutPowerState**
> ErrorValue PutPowerState (int? value)

Set the power state.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutPowerStateExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();
            var value = 56;  // int? | Value of 0 turns the display off and 1 turns the display on.

            try
            {
                // Set the power state.
                ErrorValue result = apiInstance.PutPowerState(value);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.PutPowerState: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **int?**| Value of 0 turns the display off and 1 turns the display on. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="putsharpness"></a>
# **PutSharpness**
> ErrorValue PutSharpness (string value)

Set the current sharpness. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutSharpnessExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();
            var value = value_example;  // string | Change the sharpness.

            try
            {
                // Set the current sharpness. Range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
                ErrorValue result = apiInstance.PutSharpness(value);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.PutSharpness: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **string**| Change the sharpness. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="putvolume"></a>
# **PutVolume**
> ErrorValue PutVolume (string value)

Set the current volume.  The range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PutVolumeExample
    {
        public void main()
        {

            var apiInstance = new DefaultApi();
            var value = value_example;  // string | Change the volume.  Range is 0-100.

            try
            {
                // Set the current volume.  The range is 0-100. n, +n  Change the current setting to +n.  If the sign is omitted, it is treated as a positive number. -n     Change the current setting to -n.  If there is a negative sign, it is treated as a negative number. ++X    Change the current value to current_value + X.  If there is a ++ sign, shift the specified value in the + direction.        The amount of movement depends on the OSD. - -X    Change the current value to current_value - X.  If there is a - - sign, shift the specified value in the - direction.        The amount of movement depends on the OSD. If the value of the paramter is not within a valid range the response will be an error.  For example, if 15 is specified, but valid values are 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, then an error is returned.
                ErrorValue result = apiInstance.PutVolume(value);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.PutVolume: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **value** | **string**| Change the volume.  Range is 0-100. | 

### Return type

[**ErrorValue**](ErrorValue.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

